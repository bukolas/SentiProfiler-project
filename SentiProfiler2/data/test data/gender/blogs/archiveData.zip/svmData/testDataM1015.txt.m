While Dad is busy with my little brother in the bathtub John and I decided to try and see what we got for Christmas!

I told John to wait at the dining room doorway to let me know when Dad comes out of the bathroom while I checked our presents. I walked into the den and saw them. WOW!! There are lots of presents here!! I started looking at the presents trying to find one with the name 'Matthew', my name. I found one! Please let this be the Wii I want! I hope so! Turning it over I saw that Dad learned his lesson last year with me peeking at my gifts. There was so much tape at the ends I couldn’t peek at it without ripping the paper right off! Shoot! Maybe this is the only one. I started checking the others and saw the same thing. Shoot!

 Then I heard John behind me when he yelled "WOW!! Look at all the presents!!" I turned to John and told him he is supposed to be watching for Dad. "But its not fair! I want to see what I got too!" he said. I told him that Dad has them wrapped so good I can’t see what we got.

That was my mistake. After John yelled we should have gotten out of the den and back into the living room but we had to stand there looking at the presents and arguing. The bathroom Dad was in is across the house but he hears everything we do!

"BOYS!!!"

Crap! There was Dad holding Ian standing right behind us. I knew it without looking. That man can see through walls and has super hearing! I turned around to face the music.

"Boys, if you keep this up I will start giving away presents and I will send Santa an e-mail telling him what you guys are doing. So get your bohunkeses back into the living room or to your rooms. I don’t care which but you aren’t allowed in the den right now."

I caught Dad putting together presents last Christmas Eve so I knew he was Santa but he threatened me with no presents for 2 years if I told my brothers and sister that he was Santa. I know some of his threats he doesn’t mean but this one wasnt a threat, it was a fact! 

So we went to John's room and sat talking about our presents. One more week! I’m not sure if I can make it!!