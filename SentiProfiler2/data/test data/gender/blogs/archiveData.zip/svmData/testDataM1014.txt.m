People who know me well know I love baseball. I love the sounds, the smells, the nuances that make the game different than any I know. 

It's the one game that allows those with less talent and athletic ability to prevail over those with more of both through dedication, practice, patience, and desire. It's the one game that measures the person in a way that crosses over into real life.

I coached for a number of years. What I remember from those days isn't wins and losses, but the kids, their personal fears, their smiles, their triumphs, really everything about them.

One person in particular was Peter. He was kind of a fringe player, but did his best. During one game, he missed a fly ball. He broke down in the outfield and started crying. Quickly, I sent in a substitute and met him as he came off the field. 

He needed a hug, and that's what he got, right in front of the whole world. I told him I was proud of him. I told him he was good. And, I sent him back in the game. Redemption, just like that. 

In all my years as a professional, I've never had a moment like that.