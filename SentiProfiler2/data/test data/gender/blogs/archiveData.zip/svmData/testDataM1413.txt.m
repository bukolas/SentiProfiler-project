sam is a gud person..
He's cool . never gets tensed..
Humorous ..But very cunning person..
Use to be a gud boy in Skool days . He is one of my best friends .we ver class mates in skool. Likes to criticize everyone.
Different person.. Very Smart (about 10 % of my smartness i think)

Trust me he's a gud person.

Overall - 85/100 Very gud