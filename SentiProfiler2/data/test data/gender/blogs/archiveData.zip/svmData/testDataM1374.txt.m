Do not be so dejected.This is the layer which has been created by him,ie,Mr Gadkari.This team will be given responsibility to deliver

Those who fail may even be replaced in the days to come.

A pessimist is one who ses the darkness in the light.An optimist is one who sees the light in the darkness

So be optimistic about the outcome

People choose whom they wish to choose, and not the names.The performance makes the people to choose the party.Names that matters-then does not matters.See How Mr mani Shankar Iyer has lost the election this time, and how after losing the battle in the first count,Mr Chidambaram won the battle after recounting

Do not be so broken.These are the early days.More wopuld follow