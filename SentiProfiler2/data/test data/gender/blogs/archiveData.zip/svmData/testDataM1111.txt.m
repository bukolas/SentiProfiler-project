Nasty
under the skin, we meet and see our self's in the mirror our images
superimposed, ready or not I peer into your soul and dive deep splash
landing in a pool of pain As salty and familiar as the tears that run
down my cheek your eyes don't like what I see You don't want to be me,
pain is what I see, Am sorry that I couldn't be there. So you curse at
me and smash the mirror, scream and beg for it to stop so now What do
you get, in the hands of despair just splinters of glass, and tears of
regret, Now look again and tell me what you see, a monster Is what I
plea.