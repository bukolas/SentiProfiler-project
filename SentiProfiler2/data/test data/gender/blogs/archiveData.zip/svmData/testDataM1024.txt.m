When I was a teenager I had a guilty secret I thought nobody knew about. It was hidden under the bed where I believed nobody would find it.

It was porn.

In those days porn was not something you came across every day. It had to be searched out. It had to be passed from friend to friend in brown paper, getting ever more dog eared as time went on. 

And when Lady Chatterley’s Lover was finally allowed to be sold uncensored in buttoned-down Britain the “interesting” pages were very much the worse for wear. It was an era when sex was not something most people talked about and porn was considered completely outrageous.

And to many people – free thinking ‘normal’ people - it still is outrageous.

In just a few decades society has moved from a position where family life was sacrosanct and children had to be protected from “adult” images and philosophy to an age where anything goes.

At one time the most squirm-making conversation a parent could have with a child was the classic birds’n’bees ordeal. Times have changed since those innocent days. Now, it is the internet porn conversation.

The former, although perhaps a lip-biting ordeal, was at least natural, even moving, passing on the golden question of sexuality to the next generation but the latter is depressing and there is no script because the kids know it all anyway – or think they do!

Because of the internet every home faces a tidal wave of porn whether they like it or not. For at least the past decade the default setting for porn has been ‘on’ and parents are expected to guard children from all manner of imagery.