Chiputu is how i call this 'thin frame' if i dont call him Hari. Some of the things that comes to my mind when i think about him:

1. He is always seen doing bowling actions at home.
2. Always on phone.
3. A mini google - I dont know how he gathers information about someone. But he seem to know everyone and about everyone. :)
4. Positive guy.
5. Cannot drive a two wheeler with gears. (Sorry Hari)

The only thing i dont like about him is the fact that he likes the actor Vijay.

I am new to Orkut and hence dont know if i can come back and add few more sentences about him. If not, i will conclude saying that he is a sweet chap and a great friend.