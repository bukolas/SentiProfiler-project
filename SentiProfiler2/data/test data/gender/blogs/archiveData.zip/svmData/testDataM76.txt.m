AND BY THE WAY...
UPDATE:
And I gotta say, pissed as I am about this, I STILL think Brian and Stephen are two of the really great ones in game journalism right now...and I still consider Kotaku my fave site for game news...that said, this pisses the shit out of me....but no need to throw the baby out with the bath water I suppose....
++++++++++++


You gonna fucking quote from my blog, the least you could do is print the whole mother fucking thing. Here is what just got detailed over at KOTAKU:


[I]f I owned the rights to TWISTED METAL and GOD OF WAR, I sure as hell would at the least send a sternly worded legal letter.
Heck, I'd send two legal letters if it were me.
I mean, first Microsoft puts out a car combat game and calls it SCRAP METAL?
Hey, looks like a great game! Right up my alley! Day one purchase for me. But come on guys, isn't that just a little too close to Sony's own car combat game TWISTED METAL?
And then Sony has GOD OF WAR, a game and potential movie about mortals fighting ancient Greek Gods. And then this movie gets announced called WAR OF THE GODS about- yep!- mortals fighting ancient Greek Gods.



Oh my, they left out the last paragraph...you know, the part where I make it CLEAR I am talking about game titles and not Sony suing over game CONCEPTS. What's the matter Kotaku, run out of fucking space on your blog? You couldn't afford to print these last few lines from the original post?





And look: Sony doesn't- and should not- own the concept of the Greek Myths. Nor should they own the idea of mortal fighting ancient Gods, Greek or any other kind. That's all public domain stuff. But the TITLE? Sony DOES own that. And GOD OF WAR/WAR OF THE GODS seem a little too close to comfort ya'll.

Anyway, like I said, not my fight. I don't own shit! :)


Yeah, I can see how that would have really added so much length to the post. What, did you run out of virtual ink? 

Nah, better to remove that part and- in my opinion- make me look like I was going off about lawsuits and thinking that Sony should own game concepts. And let's leave off the smiley face emoticon at the end of the post that- along with the picture of Chris Rock from a Kevin Smith comedy and the title of the original post (also a line from the same Kevin Smith comedy)- makes it clear this was a lighthearted observation and not a serious claim to anything.  Good move there guys. 


Anyway, I hope you guys will cover our games in the future. There are numerous companies and numerous people- not just me- who are busting ass to make our stuff. So I hope we can all count on a fair shake when you play and cover our games. But please- fucking stop covering me. You clearly can't do it right. And please, don't call me for any more favors. I have a feeling I'll be busy.

Thanks.

David 






POSTED BY DA CRIMINAL AT 4:11 PM
THURSDAY, MARCH 04, 2010

KRATOS HAS ARRIVED!


Look what FED EX just dropped off!

To Stig, Scat, Whitney, Allan, Tim, Christer, Ken, Todd, Johnny HaHa, Johnny Hight, Jason, Shu, Matt, Scott, JoJo W, Max, Phil,  and hell SO MANY MORE peeps (from the original team and new folks along the way that I just don't have the time to ramble off)- thank you so much for bringing Kratos back to the world in such a grand, amazing style. What an amazing achievement!  I hope you all are as proud of this game as us fans are excited to play it!

And Allan, thanks for the advanced copy!

David