Cell phones have allowed us a tremendous amount of freedom. We can talk to our friends wherever we may be, make dinner plans, chat with our relatives, and yell at our cable provider from any place in the world. They have freed us from the bondage of land lines and the tyranny of the corded telephone. But there is something cell phones have not been able to free us from.

And that is the wrong number phone call.

I got my first cell phone in college. I was actually studying in Italy and it was more for emergency purposes than anything else. Nobody except a couple of friends back home and my parents knew I had one. I didn’t really get many wrong numbers. And if I did, they were in Italian and I couldn’t understand them anyway.

When I got back to the states I got my first brand spanking new cell American cell phone with what I thought was a pretty random Arizona cell phone number. Little did I know that number was 1 digit off from the Sunburst Resort.


People would call me and the conversation would go like this.

Hello?
Hi I’d like to make a reservation.
What?
I’d like to make a reservation for the 26 through the 30th of next month.
Um…. What?
Is this the Sunburst resort?
Oh. No.