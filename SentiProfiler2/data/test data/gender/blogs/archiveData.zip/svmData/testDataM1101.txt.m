As I write at 10am, it is 26 degrees.  The low last night was around 20, the worst of a series of overnight freezes here in Central Texas since December and on the way to becoming the coldest winter on record.  

Last summer was the hottest on record.

It leaves me wondering if whatever is going on with the climate isn't so much global warming (although overall, it is) as extreme fluctuations, like a swing with a bonfire on one side and an iceberg on the other.
If so, how far each way will it go?

Maybe it's just a coincidence.