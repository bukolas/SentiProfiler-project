When former New York Times editor Howell Raines decided to attack the Fox News Channel and blame the news outlet for President Barack Obama's shortcomings, there was bound to be a response.

And delivering that response was "The O'Reilly Factor" host Bill O'Reilly, who called his show "the signature broadcast" of the network. O'Reilly dismissed Raines as a lunatic. However he was also critical of The Washington Post for giving him an outlet to trot out his ranting.

"[I] think there is a more important thing in play here," O'Reilly said. "The Washington Post has given this guy Raines a big platform on Sunday, this coming Sunday, to print this nonsense and it is nonsense. If Raines were sitting here I could carve him up and he, Raines knows it."

But O'Reilly questioned why the Post had decided to give Raines the space in its upcoming March 14 issue to rip on his network. According to O'Reilly, this was an effort to rally the media for a last stand.

Read more: http://newsbusters.org/blogs/jeff-poor/2010/03/12/o-reilly-blasts-raines-anti-fox-news-op-ed-shame-washington-post#ixzz0iPLXscJC