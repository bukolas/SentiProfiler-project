hmm ya..am yo jolly go rocker..wanna look really serious but unfortunately i dont..lol..
then i play badminton...
i sometimes get crazy when anything abt beckham..he he
and abt my features ..u better look at my album//
lol..no place for the slightest emotions in my life..many hate that in me..lol 
ah then..the usual.. friendly ..bla bla nonsence..
being a saggitarian ..i keep trying different things and u know the result..then i do beleive i have something spl in me which could only be felt..so catch me up!!!