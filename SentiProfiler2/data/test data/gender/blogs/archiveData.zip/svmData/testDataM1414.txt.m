mahesh..met this guy in my 12th tution class..glad i did..
very calm down to earth guy.teacher's pet.speaks only if u provoke him,.responsible person.
v hav many common interests like politics, ppl v hate,(tat1 too):)..we equally detest those dumb-looking-clowns hookin wit ulti figs in our presence..
a v passionate player of cricket..he'll kill u if u misfield or come late to the venue :)
Talk to him thro electronic means n u'll feel he's v v cold.. actually he's not.he has a very gud sense of mokkai,.
instant fren catcher and a big moral support for us,his frens.
great writer too - he won the 2nd prize in essay writing n college talent hunt(mentioning coz most mite not no)..
i can never forget the time we spent in so-cald combined studies kalasifying u all nite, hanging out wit our gang, playing endlessly n lots go unmentioned here!!