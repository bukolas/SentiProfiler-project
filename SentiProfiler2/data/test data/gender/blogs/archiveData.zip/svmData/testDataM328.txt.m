I am sorry guys, but I was wrong. I thought with the release of Trenches on YouTube and other sites that it would be available for our overseas viewers. I was wrong, but I am told Crackle is looking into foreign rights. Sorry, I guess you can do a PSP or something maybe. OK .. I know a lot of you viewers are overseas and not in the US and Crackle only has release rights in the states. You have been asking when can I see Trenches? Well you can watch the episodes now on YouTube!

Yep, so go get your Trenches fix on and I hope you guys enjoy it!
Go share it and comment all over.

Here are all 10 Episodes which you can of course embed and share on your websites and solcial networks.