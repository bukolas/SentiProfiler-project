Haven't posted here for months. All sorts of reasons and, simultaneously, no reason at all. It happens or it doesn't. Many's the time I've started writing a post and it's never come to fruition. That's just the way it goes.

There've been all sorts of lovely and important cultural events since I last posted. Maybe I'll get round to talking about them, maybe I won't.

I'm not long back, this evening, from a standard (I'm thinking of it as equivalent to Classic Coke) Duckie in terms of both Readers Wifes being present and correct. Amazing music, played in just the right order, some of it having gradually accreted danceable fabulousness over time (MGMT's Kids) and a good dollop of old favourite loveliness.

Amy commented on there being a "Back To School" vibe and, although my own work is constant through spring, summer, autumn and winter, I can see where she's coming from.