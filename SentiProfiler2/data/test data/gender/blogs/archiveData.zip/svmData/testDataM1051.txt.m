They say Jesus was a good man and an excellent role model for us as modern day society but, as you will see below, I have strong reasons to dispute this. 


Assuming that Jesus even existed at all, and going on what I have read about him, I can only conclude that, while he may have had some goodness about him, he was little more than one of many mentally unstable, intimidatory, self-conflicting and self-serving preachers who roamed the hot deserts of bronze aged Palestine and perhaps we should consign his memory to the history books along with Zeus and Horus upon whom, many suspect, he himself was based.


I have decided to be fair though and will respectfully give Jesus his due to start off with. Here are some examples of the few praiseworthy aspects of his work on earth.