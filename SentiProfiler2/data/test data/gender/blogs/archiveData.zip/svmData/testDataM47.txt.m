Hand Made! -  It's been really very long since i have hand written a letter to anyone! May be the times have changed too fast. Even on festivals we just do away with SMS or a courtesy call. I wonder how Archies business is going on!

Those were the days when Archies Card could come "in a very special way", as the punchline goes and makes you happy! Alas, that was taken by e-card and now just email or SMS.

I think we should once again start this tradition of hand written letters or at least Cards, certain emotions are better expressed in original hand writing.

I had few of the greeting card with me which were given to me long time ago on various occasions and whenever i look at them i go back into the memory lane, and believe me it's a wonderful feeling altogether.    Holi - Festivals of colors
Holi is associated mainly with colors, but for me the association is more then that. The festival reminds me of colors, water balloons, gujiya, papdi+achaar, Kanji Vade to name a few.

I remember my childhood time when we use to play Holi with great enthusiasm. Neighbors use to visit us in  groups and pour color on my parents fully knowing that they are already covered with enuf of it. Sometime they use to color my face as well and i use to run away.

What i do not like is the smell of the colors, it has a pungent smell which i somehow don't like. So most of the time i use to wash my face just after the group was gone.There use to be Pooja at home and then Lunch full of calories. I use to love Aloo kachoris at that time. 

It was great fun until sometime later when the whole perspective changed and the fun element went missing and hence i stopped celebrating Holi. Festivities need to be revisited, on a very high priority basis.