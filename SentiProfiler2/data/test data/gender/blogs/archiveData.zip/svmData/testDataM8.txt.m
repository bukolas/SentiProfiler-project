Buddha, one day, was on deep thought about the worldly activities and theways of instilling goodness in human.The following is the text of conversation between him and his disciple  One of his disciples approached him and said humbly " Oh my teacher ! While you are so much concerned about the world and others, why don't you look into the welfare and needs of your own disciples also."
Buddha : "OK.. Tell me how I can help you?"
Disciple : "Master! My attire is worn out and is beyond the decency to wearthe same. Can I get a new one, please."
Buddha found the robe indeed was in a bad condition which needed replacement. He asked the store keeper to give the disciple a new robe towear on. The disciple thanked Buddha and retired to his room.
Though he met his disciple's requirement, Buddha was not all that contended on hisdecision. He realized he missed out some point. A while after, he realized what he should have asked the disciple.

He went to his disciple's place and asked him "Is your new attirecomfortable? Do you need anything more ?"
Disciple : "Thank you my Master. The attire is indeed very comfortable. I need nothing more"
Buddha : "Having got the new one, what did you do with your old attire?"
Disciple : "I am using it as my bed spread"
Buddha "Then.. hope you have disposed off your old bed spread"
Disciple " No.. no.. master. I am using my old bedspread as my window curtain"
Buddha " What about your old Curtain?"
Disciple "Being used to handle hot utensils in the kitchen"
Buddha : "Oh.. I see.. Can you tell me what did they do with the old cloth they used in Kitchen"
Disciple : "They are being used to wash the floor."
Buddha "Then, what about the old rug being used to wash the floor...???"
Disciple "Master, since they were torn off so much, we could not find any better use, but to use as a twig in the oil lamp, which is right now lit inyour study room...."

BUDDHA SMILED IN CONTENTMENT AND LEFT FOR HIS ROOM.

We all are blessed to have a living example in our life in physical form.

Jaigurudev !!!