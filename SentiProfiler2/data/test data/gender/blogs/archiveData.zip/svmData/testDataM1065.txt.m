This today would be alright to have on main stream ads or billboards and even TV commercials because it's what WE have made socially acceptable. BUT more often than not if it were someone with a lot more clothes on heavier and maybe braces.

Because if two girls like this were kissing it'd be more unacceptable. 

Why is it that a woman can publicly have a relationship with another woman and also be interested in men and it is completely valid and truthful? 

While often times if it were two men kissing, or two straight men exploring their sexuality (like many girls do.)

They'd be considered gay.

So is it a double standard in terms of us allowing woman to 
explore sexually anything and we don't allow the same for men. 
Is it possible for people of every day too put aside the cock blockery bull shit we read in the magazines that say size double D tit's and 12 foot cock be what everyone should look for in a person?





I'm not quite sure if anyone can really just act upon what they want and essentially just DO as they please or who they please weather that mean a guy for one night plays pocket pool with another guy, or a girl play slap happy with her tongue and another girls Pikachu? We've created so many restrictions for ourselves to only play in this little circle that society says is okay too play. I've always believed true rebellion comes from an education and I think people need to begin to educate and talk about something like sexuality and letting it be more of some thing that everyone can explore.

I mean isn't that sort of an attepmt at trying to discorver who you are as a person? & since when was that such an awful thing.

Quite an odd thought to think about. The idea that everyone if not anyone might look at people weather it was a man or a woman "for who they are inside", instead of someone's sex. You hear about people who always say "I go for personality not looks" really it seems no one really does. How many people do you know that look at someone's personality before they look at social status, main stream idea of what's beautiful, or even the sex of a person.

Are we only built to not be sexaully attracted to people for who they really are?