A to Z layoff.. "WARNING" A: please do 'this' for me
Z: yes sure, my pleasure

A: Hi, can u do 'this' for me....
Z: yes sure...

A: Hi, do 'this' for me...
Z: OK

A: Do 'this' for me.
Z: OK 5 minutes

A: need 'this' ASAP
Z: will be done ASAP

A: need 'this' ASAP, inform when done.
Z: OK {after sometime} needful has been done

A: please tell me the procedure to do 'this', so that the communication gap is not involved in the process.
Z: Here is the 'procedure'. In case of issues contact me

A: 'Issue'
Z: 'Resolution'

A: Hi Z, what do you do here...
Z: 'this'
A: 'this'? I know 'this', what do you do?
Z: nothing!