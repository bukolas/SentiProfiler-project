A Billion IDIOTS!! - Before I went to see 3 Idiots , I had heard a thousand people chant about the brilliance of the movie. So , amidst all the hosannahs and eulogies that i heard chanted about the film , all the frenzied applause by everyone whenever the name of the movie was mentioned , I went to see the film at last. And did 3 Idiots live up to my expectations...??

As a movie... YES. A perfectly made , celluloid entertainer. Every performance was exceptional for its sheer energy and versatality. So , As a cinematic adventure , Hirani and Amir hold the story together perfectly.

But , 3 IDIOTS , for all its fine comic moments , is a very dangerous film. The movie legitamizes a scorn and hatred of education. It ridicules the best education institutions set in INDIA , sanctions wilful dumbing of our own. It shows our higher education system as an arena of bad teachers determined to ruin the student's lives , suicidally pressurizing students.

Amazingly , a film whose central message is "the education system sucks", " we earn nothing at our centers of excellence" , "dont study hard jusst do what pleases you" is being hailed as the best film ever made in INDAIN CINEMA. This huge popularity of the movie shows how eager we are to embrace mindlessness and how keen we are to see education and hard work as obstacles to enjoying a good life.

We keep chanting the mantra "the-system-sucks , who-cares-about-grades , the-rat-race-is-foolish.". Yes our education system needs reforms , things need to improve but in the pusuit of educational reforms , we cannot allow standards of excellence be lowered. The IIT's must be applauded for the world-class minds they've thrown up , they are institutions that are respected all over the world.

There was a scene in the film in which Rancho mocks the Laplace Transforms (the equation written on the blackcoard) as an example of rote learning. Yet, without Laplace Transforms , Hirani's computer would not boot up!! As an Engineering student, I have never come across a teacher like VIRUS nor have i ever felt the manic stress during the 3 years of my college life.

Let's get real about higher education , and not engage in an escapist fantasy and convince ourselves that education doesnot matter. For each of us, geniuses or not ... there are no short cuts.

So , THREE IDIOTS IS A GREAT MOVIE!! BUT THAT'S JUST IT ... IT'S NO MORE THAN A STORY.