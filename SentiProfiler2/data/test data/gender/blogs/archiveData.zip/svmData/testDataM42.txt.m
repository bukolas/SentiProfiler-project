Does this make sense to you? Your mother doesn't let anybody harm animals, and you surprise everyone by those statements!..I dont buy your shit that you didnt say any of it and the cd is doctored..I dont think im jumping the gun either, you did that probably and are paying the price of it..  Why is Shashi Tharoor contesting elections from Trivandrum?..I just saw a flash news of the same, dont know if he has some ancestral connections with that place..If he doesn't, then why!

I have all the respect for Sanjay Dutt. That is, if I ignore his failed marriage, a controversial 2nd marriage(or third, srry ive lost track), his involvement(rather, his conviction) in the mumbai blasts, and the fact that all he'll utter in his campaigns is 'Gandhigiri'(a term thats not his)..

The next time you stand up and question Sachin's honesty I'll take it as a personal insult..and none of you would want that..coz I 'am' the cricket crazy indian public..

Is Austria gone crazy?..A man gets convicted for 14 years, even though the duration of his offense in itself was 25years!..cmon!..

TATA sends me an email telling me about this wonderful broadband connection that has 'not much hidden charges'!!..its written right across the middle..Should I just laugh, or sympathise?

Mira Nair re-releasing Salaam Bombay..Woman are you out of your mind??..The then child artist would still be driving an autorickshaw in bangalore..and if his condition doesnt improve then whats the point??

No multiplex releases for movies after april 3?..Producers digging their own graves..Atleast wait for the recession to get over with..So that you can recover some dough from the stock markets..You've ruled the industry for a long time, let someone else call the shots now..the end audience will still pay the same if not more..

Why..
Why..
Why..
Why..
I ask.