hummm vivek wht to say ??? i have never seen such a person in my life .very shrewd and intelligent person.He always views things from a different perspective.
None can think like him...Just for this reason alone, I can be your fan ..i know him for more thn 2 yrs Ever since I have known him, he has never asked me anything and has never expected anything from anyone upto i know [ eppadi unga nala mattum gi ]but a person with great helping-tendency ..
U wil know abt him fully if u move close to him..i lik his attitude towards all ....
Tnks orkut to get a brother lik dis
keep in touch always even when u go to German just kidding anna
Hum Thn all d best for ur future .
my wishes r always with u .