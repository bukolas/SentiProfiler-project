Well, that was something wasn't it? Good luck topping that upset, everyone else left in the field.

Good to see Bill Self revive the old Roy Williams tradition of bringing a talented Kansas team favorite to the NCAA Tournament and then turfing out in the second round. (I never forget a bracket scorned.) That's what you get for messing with Kurt Warner. Oh, don't think his blessed name won't come up a few times this week. If he's not sitting front row at the regional I'll eat this delicious Kansas sunflower that just shriveled up in front of me and died.

And it's not even over! Two more games for you to curl up by the fire with. Kentucky-Wake Forest and Kansas State-BYU. What's that? You've already had too much nail-biting basketball today? Well, suck it up, junior, because THAT'S JUST TOO BAD! You're going to watch and like it.

Seriously, you've come this far. What's two more games? John Wall. Frank "Don't Call Me Frank" Martin. JIMMER! It's a who's who of guys you barely know anything about, yet are oddly fascinated by. Just order the pizza and cancel the babysitter. You're not going anywhere.