I got back last week from a great vacation in Maui visiting Anna! Mom and I went together and we spent the week sleeping on Anna's porch (so lovely!), hanging out on the Pacific Whale Foundation boat with Anna and watching whales, and watching the third season of Arrested Development while drinking gin & tonics (a must-do activity for any hawaiian vacation!)


After about the first hour of vacation I re-remembered that Anna is a much better photographer than I am - so I packed my camera away for the rest of the trip and am using only her pictures for my blog posts. =) She gave me about 270 pics on a CD, and while I'm not going to post all of them, even the weeded out assortment will take some time to post here so I'm going to put up pictures in phases.


Here is a collection of my favorite whale pics that Anna sent me - they are not necessarily from the week we were there, but we did see all of these activities happen while we were out on the boat!