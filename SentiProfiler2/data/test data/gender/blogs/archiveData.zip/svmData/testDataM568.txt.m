Mirror, mirror on d wall who's the strongest of them all!!! The one, the only Ankit Rana.
But if scrape through the tough exterior you will come across a heart of gold. The problem is not many guys have d guts to do so but those who do r blessed with a buddy for d rest of their lifetime, fortunately i am one of them.
When he's not humiliating the machines at our gym, he's gaming or going berserk on his bike or biting into delicious delicacies or checking out d cars of the world over or, and this he does d most, being a support system to his pals ( excusive rights of entry into this club lie solely on his whims n fancies!!!LOLZ).
Let not his amazing sense of humour fool you into believing that he isn't focussed, he knows exactly where his destination lay, its just that he does not make a hullabaloo of it like d many other people you might have met.
Repaying you in d sholay spirit "Khali":-
Ye... dosti.. hum nahi todenge..., todenge dum magar..., tera saath na chodenge....