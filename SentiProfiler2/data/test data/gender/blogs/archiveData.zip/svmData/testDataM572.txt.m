Everyone’s in shock over what happened to the Lankan team. None more so than the Taliban/LeT. They are utterly shocked that the rest of us assumed sportsmen would not be targeted.

This was after the Lankan team was promised President-level security. Really? If this is the protection President-level security gets you, I don’t blame Zardari for signing that pre-emptive deal with the Taliban.

No more sports in the country. If it’s any consolation, Pakistan can continue playing mind games with India and ‘double-games’ with the US.

Yep. A call intercepted by the CIA confirmed that the Pakistani military is still actively supporting the Taliban. So Pakistan is happily absorbing billions in free aid whilst merely pretending to help America in return. Kinda like AIG, when you think about it.

It’s been 2 days and no real leads. Zardari has assured everyone that the state is the doing the best it can. Sure, but no resignations. None so far. Shivraj Patil was not reachable for comment.