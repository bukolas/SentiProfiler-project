1. Avoid them, or
2. Do the harder thing (Which, in my opinion is always the best), and empathize with them and their issue.

You can't change anyone, but I think if you empathize, that builds trust, and you could possibly have the opportunity to offer some steps to correct the looping path away from the issue. I'm not a professional counselor (I'm think you might not be either), but caring for someone and their issue can open up your heart and mind to offer caring advice from time to time. Love and empathy can help you help others.

All this is hard. Life itself is hard, but sometimes the hardest lessons are the most rewarding.

Practice empathy. Do your best to set aside the instant platitude, listen and be empathetic.

The world is full of people going through difficult times, and if you take some times to start to practice empathy, you could have the opportunity to release the pain of one person, and that could have a positive ripple effect.

I'll leave you with this. This has happened to me. Sometimes the people that you help with empathy, can turn around and help you in a future time. We are not on this planet to be on our own, we need each other.

Have a great week. Another little distraction coming next Monday. Tell a friend. :)