Aishu alias “KP”(guess what?  ) alias Demagogue s one of my closest nd best frnds nd the first person to tie me a rakhi  Always the source of support..
Honest, good-at-heart, highly conservative(!!), studious(first bencher and favorite of staff!),passionate about programming and slightly submissive (she likes male chauvinists or even those who pose so  guys note it down!) – but trust me she s not the girl u assume her to be  
An epitome of friendship (u can call yourself lucky if she “really” counts you as her close friend!) and its funny when she gets angry  coz its so easy to make her laugh uncontrollably, the very next second…One person out there who is good and always tries to be so! Quite a trusty person (lol good that she is..she knows FAR too much about me!) and one who respects others’ opinions!
U can really bank on her as a friend to sort out things for u when in need of help!I will surely miss this frnd and sister a LOT, after leaving SSN!
Wishing you a gr8 future!
Arun