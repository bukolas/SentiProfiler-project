A few days ago Ken Cuccinelli, Virginia’s new conservative Republican attorney general, “advised  the state’s public colleges that they don’t have the authority to ban discrimination based on sexual orientation, saying only the General Assembly has that power,” producing a stampede of criticism not only from the usual suspects but also others  who are not reflexively anti-Republican.

On March 9th, the Washington Post reported:

    More than 3,000 people joined the Facebook page We Don’t Want Discrimination In Our State Universities And Colleges! Nearly 1,000 people joined another, started by activists at the College of William and Mary. The University of Virginia group Queer & Allied Activism urged students to protest on Cuccinelli’s Facebook page and on Twitter.

    Students at Virginia Commonwealth University, one of the few in the state not on break, planned a rally for noon Wednesday, with several hundred students committed. At Christopher Newport University, student Republican and Democratic leaders will discuss their next steps at a bipartisan meeting Friday.

    “I’ve never gotten so many e-mails from students wanting to do something,” said Brandon Carroll, 21, president of the student government at Virginia Tech. He said any erosion in gay rights at state universities is “going to make us lose top students. It’s going to make us lose top faculty.”