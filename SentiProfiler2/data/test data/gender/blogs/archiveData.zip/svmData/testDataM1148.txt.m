had a very enjoyable debate with Avner Rosen of Boxee yesterday at SXSW.  We tended to go around in circles defending our positions. His (to paraphase): the internet will do what cable and satellite do, but it will do it better. That MicroSoft and Apple among others will in the future come up with new ways to do it all better than we can now.

Mine: Of course the internet can support video, but it cant do it as well as the current digital cable and satellite distributors can, nor is there a profit model that would ever incent content providers to switch their content from the internet to TV.

I wont rehash it all here, but the most salient comment came from the audience when someone asked “Whats the difference if the gatekeeper MicroSoft/Google/Apple rather than Comcast/Time Warner/Directv/Dish ?”

Of course the questioner was right.

Bits are bits . The economics of content are going to search for the best place to be monetized, regardless of the delivery platform.  I think the current model will be the place content finds, Avner seemed to feel it would be some future internet.

It shouldn’t matter.

We both seemed to agree that one of the biggest future changes for the internet will be an increase in bandwidth. The question the needs to be answered is “how will all the new bandwidth, both on the backbone and in the last mile be used ?”