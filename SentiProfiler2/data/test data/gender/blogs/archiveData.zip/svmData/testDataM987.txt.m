My friend Jasyn recently posted this on my last blog, first time I had seen it and I love it now.  I wanted to share it with you.  Whoever put this together did a great job, I've watched 2 other videos in the series and this one is the best in my opinion.
    I was excited to show it to my oldest son, who is 4 and loves both science and music, and he really liked it.  We got to go over who each of the people were, what they studied, had accomplished, and what they were saying.  He has wanted to be an astronaut since before he could talk and has always loved science.  He was most amazed that the guy said that scientists love not knowing.  "Don't scientists know everything?" he asked.  "No", I replied, "and that is why they are scientists". 

My favorite quote was by Neil deGrasse Tyson:
"When you are scientifically literate, the world looks very different to you, and that understanding empowers you".
So empower yourself.  Study.  Learn.  Question.  Repeat.
My son told me the other day, "Dad, I'm a scientist, AND an expert, AND...." his voice got real soft for emphasis... "a real ninja!"

Expert ninja scientists, however, is another topic for another blog.  Don't want to blow your mind here or anything.

Peace!
Mark J.A.