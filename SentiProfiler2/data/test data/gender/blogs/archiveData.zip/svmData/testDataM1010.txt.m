Well, I'm back from the outer space that is the holiday season. I trust you all had a great holiday?

Relatively uneventful on my end - just some good times with friends and family and usually a few drinks to close out the night.

Most interesting part of the holiday was that Mrs. Shambles's grandmother is in a nursing home right now. And when we visited her, the woman she's sharing a room with, separated by a curtain, kept asking us (apparently Nancy and Bob) how the food was in Jamaica and how big the plane was and why we kept talking about Cincinnati when she knew that we lived in North Olmstead before we went to Jamaica, of course.

When we said we lived in North Carolina before that, she got totally confused.

Oh, and that one of my relatives may soon begin smoking weed due to a medical condition. 

And it was snowing and I'd had little sleep and a sugar free Red Bull, but driving back home I either saw the body of a giant sheepdog or a small Yeti.

So I guess it was a little interesting.

I wish you all the best in the coming week and year!