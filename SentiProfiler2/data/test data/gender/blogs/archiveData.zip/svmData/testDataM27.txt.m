Sorry, Charlie

Until recently, it was assumed that Charlie Crist, Florida's gay Governor, would take an easy walk from Florida to the US Senate in next November's election. Until Charlie's support started to crumble around him, that is.

A Rasmussen poll from last week shows that Crist's primary opponent, Mark Rubio, brought the race to a dead heat: 43% to 43%. In an effort to court the conservative wing of the Florida GOP, Rubio is running hard to the right. A hard right wing Senate candidate would be a much harder sell to the people of Florida than a popular Governor who enjoys an approval rating of 68% of Democrats!

As if that is not enough, Lincoln Diaz-Balart and Mario Diaz-Balart (pictured), brothers who serve in Congress, have withdrawn their endorsement of Charlie and Rubio continues to press hard. Florida's GOP is conservative and Charlie pitted against Rubio could mean that the Governor could lose his primary election and be out of a job at the end of next year. Crist had to make a choice between running for Governor or US Senator. Perhaps it he picked the wrong one.

In the report, Lincoln Diaz-Balart explained that Crist had 'left us [the two brothers] no alternative and he knows why.'

Do tell Lincoln, do tell.

By: Michael Rogers | permanent link |   
Comments (4)
Tuesday, December 22, 2009

Huck goes pro-gay

Well, he's supporting a gay guy for public office. Of course, a few weeks after a guy you paroled slays four cops you'll do anything to change the narrative about yourself.

Andre Bauer gets Huckabee's backing:
Lt. Gov. Andre Bauer is being backed by former Republican presidential candidate Mike Huckabee in the GOP race for governor.

Huckabee, who served as governor of Arkansas before finishing second in S.C. Republican presidential primary in 2008, endorsed Bauer in a fundraising letter for the lieutenant governor and Huck-PAC, Huckabee's political action committee.

'Andre Bauer is a champion we can believe in,' Huckabee wrote. 'He has fought for the people of South Carolina since the day he was elected to the House of Representatives in 1996. As Lt. Governor, he has ruled against every single proposed tax increase, saving the people of South Carolina $2 billion.'"