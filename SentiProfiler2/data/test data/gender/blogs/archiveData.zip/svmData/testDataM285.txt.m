Chris - is having a nice Friday afternoon relaxing on the XBox and then he might have to do some planning for his girlfriend Sophie's birthday next week. He also has to cook for his friends - one of whom is a vegetarian, then tonight he'll be watching the Sport Relief coverage on BBC1 from 7pm and his Quiz Night on Channel 4

Dave - will be heading west to Pembrokeshire, specifically Haverford West, where he, Dom and Aled will be playing all the hits tonight

Dom - as above

Aled - as above, but he's being picked up by his Mum and Dad (who have to travel 60 miles)

Tina - is going to her friend's welcome home party; she's been working in India for the past year

Matt Fincham - is filling in for Rachel today and then tonight is going clubbing with some friends CHRIS - is off to see Alice In Wonderland with his girlfriend

DAVE - is finishing off a lot of work and then he'll be going high diving with Fearne Britton*

DOM - is presenting the Oddbox today and then might be ringing up a local radio station

TINA - is undecided

ALED - has a meeting in work with the new Rachel (Sam) and Matt, and then he's going to see his trainer

MATT - is filling in for Rachel for the next two days as she's off in Copenhagen to give a speech about radio

* this might not be actually happening Chris - is having a meeting with Executive Producer Piers about some important bits and bobs and then he'll be celebrating St Patrick's Day

Rachel - is up to lots of work in the office and then she's getting ready to go to do a talk at the Copenhagen European Radio Conference

Dave - is doing assorted jobs, celebrating St. Patrick's Day and then having lunch with Steve Brookstein*

Aled - is working on a presentation, going to playlist, having a sleep and then having a surprise evening for his other half's birthday

Tina - is going out for lunch with the girls as it was cancelled yesterday and then she's looking into getting some singing lessons

Dom - is playing volleyball with Alexandra Burke* and then presenting the lunchtime Newsbeat programme; he also needs to recover from the football yesterday.

* These things might not be actually happening