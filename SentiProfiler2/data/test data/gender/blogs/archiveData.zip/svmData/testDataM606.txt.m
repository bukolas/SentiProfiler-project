wat can i write abt this guy,u need to think a lot
if u wanna write abt him.A picture perfect for a college going bloke.
very childish in his own ways,almost evrybody in clg is friend to him.
first evryone said he's a bookworm,but whn i saw his pic(the one with coolers),no one will
say ever he's a padips.he's more than a book worm,a voracious reader,but his effects are limited to only
clg syllabus.Try 2 improve ur scope da.machan doesnt know anythin abt english muvies or songs,tht disappoints me.
being ma good comrade,i want 2 u sharpen things on tht.No matter u can ask my help anytime.
This little soldier has a gr8 future 2 come and i can see tht(this is gotto be the greatest lie).