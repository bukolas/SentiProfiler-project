The dinner plates began to go cold. Some would say eat while you can. Others would say as long as you can is all that matters. The masters of the world know that the key to life is in their hands. So, they pull the strings and manipulate. Because, they know you'll jump through hoops to get what they have.

The game of life used to be survival. And now, the game of life is slavery. Ha. They say life is unfair. Well, why do you think that is?

Give me more Britney Spears. Give me more MTV and TMZ. Tune me into your programs. My brain is still unclean. It needs more washing. Whatta' ya' say, Uncle Sam?

Whatta' ya' say Obama? Ha. I'm being puppeteered by the puppet.

You win America. We are your slaves. Now hand me that big check that isn't quite big enough and dangle the food above me.

Just don't get comfortable. Karma will come to collect. Lololololololololzzzzzzzzzzzzzz. Fruits.