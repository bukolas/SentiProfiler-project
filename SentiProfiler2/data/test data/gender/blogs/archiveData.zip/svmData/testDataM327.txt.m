Because I'm quite anal, I will have packed on Thursday night. So, after Strictly, I put my bags in the car and I'm off. My dog, Peggy, is a Shih Tzu cross. She's also a cross Shih Tzu. She tends to bark. She doesn't like men or other dogs.

I go south to a cottage I rent by the sea that's quiet and remote. On my perfect weekend, all food officially contains no calories. So at the Wandsworth roundabout drive-through, I make one of my bi-annual visits to McDonald's, wearing a cap pulled low in case friends or family see me.

After supper, I put a musical on. My current favourite is Annie. I perform all the parts as I drive down the motorway.

When I get there, the first thing I do is look at the stars. I love spaces and views. I get very claustrophobic in London. My muscles relax and my shoulders drop as I, literally and metaphorically, count my lucky stars.

There's nobody else there, which might sound odd for a single woman. Most single women I know are pining for a boyfriend or husband, but I love being on my own.

But I chat to Peggy like a mad eccentric. I've always been old before my time. So I'll also be in bed before 10.

Fully refreshed after 10 hours of sleep, I'm ready for a hearty breakfast at a local café. Next, I lie on my back, and breathe out all the week's stresses with the Alexander Technique.

Feeling very aligned, I go for a lovely cliff-top walk to "blow the cobwebs away", as my mother would say.

Then I take a picnic aboard a little rented put-put boat on an inlet like Itchenor and pootle about. I like watching birdwatchers because they're seriously tense and they love cagoules unashamedly. Afterwards I feel I deserve a proper post-boating British tea: scone, a cup of tea and cream and jam. Just heaven.

On Sunday, it would be a light cereal breakfast. Special K is a massive treat. Cereal has so much sugar in it.

Then a lovely walk to a pub for Sunday lunch, because there's nothing better than Yorkshire pudding. On the way, I'll visit a house where a writer used to live for inspiration.

I'd head back early to miss the traffic, put a wash on and get ready for the week before watching a film. I find writing stressful, so when I've had a wonderful weekend like this I want it to go on forever.