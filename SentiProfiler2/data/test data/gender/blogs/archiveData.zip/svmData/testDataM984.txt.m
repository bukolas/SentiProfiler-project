I appreciate you stopping by to sample a bit of my world behind the camera. I have been very blessed to have had the opportunity to travel and see many great things. During those travels I took many common photos of a far away land that opened my eyes to the common things we see everyday here in the midwestern USA.
I decided that these local common things were very worthy of my photographic attention. I have deliberately sought to pay more attention to my surroundings. Many call that "stopping to smell the roses". I have found that to be good therapy.
This website records many strange events or happenings. It explores wild abstract color and different ways to view things. I have always enjoyed intense contrast in photography. To me, color splashed everywhere is great ... sometimes even enjoyable pushed to the bizarre with manipulation programs.

Interested in having something photographed? Send your inquiries to nikonsniperguy@aol.com. I just might hop in the car and get it done.

Thanks for coming. I enjoy your comments and hearing how a photo strikes you. All the best