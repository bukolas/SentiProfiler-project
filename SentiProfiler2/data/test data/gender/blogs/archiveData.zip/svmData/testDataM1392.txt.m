steffi:
1.when u r sad-i will help u get drunk and plot revenge against the sorry bastard who made u sad.
2.when u r blue-i will dislodge watevar is chokin u.
3.when u smile-i will know u finally got laid.
4.when u get scared-i will rag on u abt it every chance i get.
5.when u r woried-i will tell u horrible stories abt how much worse it cud b.
6.when u r confused-i will use little words.
7.when u r sick-stay the hell away from u till u r well again,i dont want watever u have.
8.when u fall-i will point and laugh at your clumsy ass.


thank GOD u hav a friend like me...!!!