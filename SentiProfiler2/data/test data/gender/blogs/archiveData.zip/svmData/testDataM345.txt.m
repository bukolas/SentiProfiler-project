The International Skating Union has decided to allow Olympic bronze medalist Joannie Rochette of Canada to perform an exhibition tribute to her late mother at an unsanctioned competition Thursday in Connecticut.

That decision comes in the wake of criticism that included a blog entry I wrote Sunday taking the ISU to task over its unwillingness to bend rules given the unusual nature of the situation.

Michael Slipchuk, high performance director of Skate Canada, sent a Tuesday email to concerned parties with the ISU's decision.  Here is its text, from a copy obtained by the Chicago Tribune:

"The ISU has agreed to relax ISU rule 136 for Joannie, due to the unique and extenuating circumstances of this particular request,  and allow her participation in an exhibition number only (not a competition) at MGM Grand at Foxwoods, USA.

"Therefore, Skate Canada has also granted a sanction for her participation in this event."