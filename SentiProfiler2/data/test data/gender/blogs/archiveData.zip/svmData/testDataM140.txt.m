So tomorrow, is St. Patrick’s Day.  And here I am having given up alcohol for lent.  Someone didn’t think this thing all the way through.  I mean, who hell would put both my birthday AND St. Patrick’s Day right in the middle of lent?  That’s some stupid planning if you ask me.  

Speaking of Ireland, as you guys probably know, way back in the day I sent out a plea into cyberland asking for information about my ancestors.  And, as you know, it was answered.  I got an email from someone who is a cousin (not sure how distant, these things confuse me) with some really cool information about the Loy family.  

Loy family being my great great grandfather George Loy who was born in County Armagh Ireland.  We found out a few things like his father, Thomas Loy and several brothers and his many, many kids that he fathered. Also, interesting tidbits about George like a newspaper account of his doing time for assaulting someone.  Apparently I come from a pretty rowdy bunch.  Shocking, huh? 

I also shared with you this picture….


At the time we thought this was Thomas Loy, George’s brother.  Well, turns out it probably isn’t Thomas. 

How do we know this?  Cause I got another email from another cousin with EVEN MORE information about my family!  How cool is that?  

He has provided us with scans of all kinds of great stuff.  Baptismals, death notices, marriage certificates (mostly in Latin), census entries and even immigration entries.  All of it adds up to help create a great timeline and fill in some of the pieces of their lives. 

Oh, and the guy in the pic?  We now believe it is John Loy, another brother of George Loy.  He was an army reservist in the 1st Regiment of Foot, aka The Royal Scots.  

Tragically John died of drowning while bathing in the river Tees.  My newly found cousin sent the death certificate.  

My newfound cousin even sent us information on my mother’s grandfather Edward Wilson.  We knew he was born in Belfast, but really had nothing at all.  My cousin was able to dig up information about Edward moving to England and when he immigrated to the US and all kinds of great stuff.  

How cool is that?  Yeah, pretty damn cool.  

Well, that’s it.  I just wanted to update you on the family search cause I know you were wondering how that was going. 

Also…