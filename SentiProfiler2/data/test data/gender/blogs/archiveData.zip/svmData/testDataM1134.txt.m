Hey folks,

I have asked the kind people at GoComics to do away with the ANGRY EYEBROWS comic for good. Put simply, it was an experiment that just didn’t work out. I know this comes as disappointing news to a lot of you, but this year is all about trimming the bacon fat and parlaying my talents into projects that I can be excited about.

THE ANGRY EYEBROWS COMIC CONCERN is still something I’m interested in pursuing, but not as a gag-a day comic. The plan I have in mind would be more of a web portal highlighting the current comics I’m working on, including animation projects and iPod/iPad/iPhone apps.

Thanks for those who followed the short AE experiment. More things to come in 2010.

-FRS