Notes from Mussoorie - Day 1  -   It's a clear night full of stars in Mussoorie. The chilly breeze makes me shiver under my spine and somehow i am enjoying it till the core.

Looking down is Dehra valley lit up like a golden jewel. What an amazing tapestry! Amazing view captured by my retina.

The room that i have taken is a reminder of ancient British Era. It's a heritage hotel and well kept one. During morning the Sun wakes you up as you open the window.

Balbir Singh, my room attendent reminds me of British officers who had a personal attendant saying "Haaji Sir" on every possible statement of mine.

I am enjoying my stay! Thank you Mussoorie for being so kind.   After initial hiccups i reached Mussoorie today Morning, with completely no idea what is in store for me. This is the least planned trip for me.

It was 11 by the time i reached and then after getting refreshed i opt for some walking aroound the Mall Road just to get the feeling in.

I came back after an hour with the notebook and started to settle. Since there was no planned activity i was enjoying my state of doing nothing.

After finishing late lunch generally i got the feeling as to how would it be if at all i would be able to meet Mr. Ruskin Bond, after all he lives here only! What if i could just sneak into his home and have a small conversation! Embroiled in these thoughts only i ventured to move out in search for the book shop.

It took me only 15 mins to reach and i bought two books, "The room on the roof, Vagrants in the Valley", his very first book and "Notes from a small room", his latest. I asked casually whether he visit here sometime and much to my surprize the owner said that he will be coming here anytime soon!!! This was least expected.

Though i had updated my status in FB "Meeting with Mr. Bond", but i had never even imagined it would come true. There were very few people and all were waiting for him. After sometime he came in his chauffer driven car.

There was no Tamasha, no security guards, no protocols. He was walking and talking like any of us do. Such is his simplicity. I was completely taken aback. He signed on both of the books and i chatted for a while, shared a joke and more sitting just next to him!!!

I came back to my hotel room. After sometime i realised that one of my wish has just been fullfilled. It's been so kind of him to take his time out. I wish i could meet more people like him.

Mussoorie has really been kind to me. Thank you Mussoorie.

Written on 13th Feb just before finishing the wonderful day.