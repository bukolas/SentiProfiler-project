....to the teacher!!

"He will have to learn, I know, that all men are not just and are not
true. But teach him if you can the wonder of books... but also give him
quiet time to ponder the eternal mystery of birds in the sky, bees in
the sun and flowers on a green hillside.
In school, teach him it is far more honourable to fall than to cheat...
Teach to have faith in his own ideas, even if everyone tells him he is
wrong.
Teach him to be gentle with gentlepeople and tough with the tough.
Try to give my son the strength not to follow the crowd when
everyone getting on the bandwagon...
Teach him to listen to all men; but teach him also to filter all he hears
on a screen of truth, and take only the good that comes through.
Teach him, if you can how to laugh when he is sad... Teach him there
is no shame in tears.
Teach him to scoff at cynics and to be aware of too much sweetness.
Teach him to sell his brawn and brain to highest bidders, but never to
put a price on his heart and soul. Teach him to close his ears to a
howling mob... and stand and fight if thinks he is right.
Treat him gently, but do not cuddle him, because only the test of fire
makes fine steel. Let him have the courage to be impatient. Let him
have the patience to be brave. Teach him always to have sublime
faith in himself, because then he will have faith in humankind.
This is a big order, but see what you can do. He is such a fine little
fellow my son! "

- abraham lincon

POSTED BY SHAIL AT 4:55 PM 0 COMMENTS
LABELS: GREAT PEOPLE GREAT VALUES
WEDNESDAY, AUGUST 26, 2009
Important.. undertaking or undertaker!!
Even great plans and initiatives involving foolish people,
.....becomes trivial and worthless !!!
while a small ordinary undertaking by keen and devoted men,
turns out to be the work of times, great admiration...
POSTED BY SHAIL AT 10:58 AM 0 COMMENTS
LABELS: RANDOM THOUGHTS..
TUESDAY, AUGUST 25, 2009
The Last Chance..
Its funny how life throws it upon us..
but.. everytime we are left with no hopes and only darkness around..
there is always a still waiting.. one last chance..!!