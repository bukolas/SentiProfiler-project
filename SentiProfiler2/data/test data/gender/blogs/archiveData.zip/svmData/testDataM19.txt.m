Greetings and Huzzah, pitiful earth dwellers!

Behold the beauty and awe put forth by this, my greatest triumph to date! This is the blog of the evil Grand Master Flash of the underworld! The one and only mechanical deity, TOBY, Robot Satan! Fall to your knees and promise your ever-loving soul to me!

Have you had ample time units to reach the human kneeling position?

Excellent! Fear my wrath, for from my forth floor walk-up one-bedroom perch in the doomed city of New York, I see and know all human wants, needs and eateries! Do not attempt to ignore my presence or resist my power of soul persuasion! You will surely lose, with your punishment for such insolence being the loss of all things smooth and cold!

You have now been oppressed! Through a blog!

Stop back often for evil updates and mighty pie recipes!

Yours in uncomfortably humid hellfire,

Mighty TOBY, Robot Satan