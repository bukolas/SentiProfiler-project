In the event some form of ubiquitous entertainment comes first ,  takes over the net and saturates it, how is the FCC going to solve the bandwidth traffic jam ? They wont ever be able to put the bandwidth genie back in the bottle. Screaming at broadband providers to spend the money wont work any better than screaming to expand highways helps to alleviate rush hour traffic

The FCC wants Internet 2 at universities to flourish and develop new things. But where are they going to roll them out to if all of our bandwidth to the home is being used for some new form of 3D virtual fantasy sports?

I just dont think these things will just manage to take care of themselves.  The reality is that when we run into future internet application roadblocks our politicians will jump in the mix and attempt to “solve” the problems. You know where that will get us.

We need to start the process now of putting some bandwidth to the home away for a rainy day. Not only do we need to preserve bandwidth in the last mile, but the FCC also needs to  figure out a way to create a transparent market or exchange that allows competing applications a means of knowing how and when they will have access to bandwidth when, not if,  it becomes constrained.

And if you really want to make things interesting, the company that is doing the most work on realtime markets and competing for resources that i know of ? ….. Google.

Deal with it today or struggle with it in the future.