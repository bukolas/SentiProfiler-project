I have the idea in my head of what I want the completed piece to look like. However, as this is my first attempt at such an endeavor, it is, as might be expected, taking an inordinate amount of time. At this point though, I'm comfortable enough with my rate of progress to post up the original and declare that soon, the finalized or near-finalized version should be up as well.

I hope you enjoy looking at my art, and if you'd like to see more of my abstract designs or rough sketches, please let me know!
Anything Box
I collect things that I think are neat or interesting, and I place them in an empty harmonica box in a drawer. Recently I was talking to somebody who wanted to see them so I subsequently took this photograph of all the bits in there. I think it looks pretty neat.


Photobucket


I will explain what all the items are starting from the top.

The four steel towers at the top are tapered roller bearings from a wheel bearing of a truck. They're made of extremely hard steel which is one reason I kept them. As an experiment, I placed these four in alternate directions between two hard drive magnets. After several months, when I removed them, the atoms had been realigned and the bearings are now notably magnetized.