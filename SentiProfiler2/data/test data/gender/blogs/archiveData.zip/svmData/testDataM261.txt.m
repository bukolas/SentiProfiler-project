A DIRECTOR is preparing for a homecoming as his comedy arrives in Manchester today.
David L. Williams’s British comedy Beyond the Pole kicks off its first north west airing at the Cornerhouse cinema.
The film was both directed and co-produced by David under the company he runs with real-life partner, Cold Feet and Friends star Helen Baxendale, who also stars in the movie.
David, 39, said: “I’m really chuffed this film is being showed in Manchester, it is like a homecoming.”
Though raised in Sale, David now lives in London with Helen and their three children but still has friends living in Urmston.
The couple founded Shooting Pictures in 2000.
Their latest offering tells the story of two pals played by Green Wing’s Stephen Mangan and comic actor Rhys Thomas who venture out to the North Pole on the world’s first carbon neutral and organic expeditions.
But the pals, whose idea of facing the extremities is camping in the Pennines, are in for a shock as they face challenges from angry polar bears to cocky Norweigans.
Beyond the Pole may be facing tough competition at the box office from the likes of Scorsesse’s Shutter Island and Matt Damon starrer Green Zone but it has already won a cult following on social networking site Facebook, gaining 5,000 fans, and awards at the Ft Lauderdale International Film Festival.
Describing the 14-week low budget shoot in Greenland, David added: “We shot it at a hunter’s village which had around 300 residents who were all armed to the teeth – they actually turned out to be very friendly.
“We also had to be armed because of the polar bears – it’s difficult when the bears are around and you have to have one more take because the actors need to be a lot more funny.
“It was a tough shoot but a beautiful place to film. ”
Beyond the Pole runs at the Cornerhouse from March 19 to 26.