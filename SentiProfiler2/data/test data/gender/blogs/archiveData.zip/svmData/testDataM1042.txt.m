On to next weeks seminar presentation. I'm tempted to work on my new composition. I should pick up something to eat.
Nice, I found the article Dr. Claxton-Oldfield recommended.
Brr, it's kinda cold.
I'm sure you'd suck the nipples off her if you could. Dude! She's a cartoon!
More attractive than a villain, not quite a hero.
Jake did an excellent job cleaning the place.
PB and J is devoured. I'd love to crash right into my bed, but it needs to be made. Yoga class was awesome today. Ah, my bed is made :) Ahh... Orange juice. I should like to eat something more, but what? My internet connection is not being very co-operative. I suppose I should prepare a meal of brown rice and frozen vegetables. I'm craving something sweet.
A bit of chicken noodle rice onits way. I've eaten all of my crackers. I think I'll throw some eggs into the mix.
Channel your feelings into your work
I got my bag paked, washed-up, and I'm ready to head in for the night.
I'd like to feel good about what I've accomplished this weekend. A part of feels as though this pulled muscle in my back is punishment for something I did wrong. The amount of work I got done in RDA and Social Psych doesn't help any. Dominique would count it towards Catholic guilt. Could it be so ingrained?
I'm practicaly caught up on my housework. I wish I had more time to play guitar. Pat Metheny is really good.
With any luck, I'll be up early and rested tomorrow morning with ample time to get some studying done before class. After class I'll finish up my lab and I might spend some time at the gym. On my way home I'll pick up some groceries, have supper when I get here, then pick away at the rest of RDA. I might squeeze an RDA session in while I'm on campas. One day I got through three chapters while I was working in the student center.