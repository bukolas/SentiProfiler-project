Boston Rapper Edan dropped psych-hop classic Beauty and the Beat in 2005. So long ago, that alot of us thought dood was a done deal. The album was so layered and textured that maybe it was impossible to follow-up.
Luckily, Traffic Entertainment broke Edan off with their back catalog of early 80’s rap, disco, funk and punk records.
This gave Edan more than enough to obessess over.

Like normally some 80’s Hip Hop throwback would make me want to vomit on the nearest nerd wearing a Jurassic 5 shirt. But there is no corny staleness on this.
The best I can describe is like this: Imagine its 1979, Hip Hop is burgeoning but you still listen to Black Sabbath. One night you smoke dust before painting a Subway Car. Afterwords, Your painting partner invites you to a park jam in the South Bronx where doods are relaying all kinds of records and chanting wild shit over a p.a. You’re buzzed off the xylene in the paint, and the joy of just doing your name big. You are faded and amped at the same time. Although you’re bugged out a little, you’re a chill bachleour. Still a royal charmer; So thru all this you pull a flygirl in tight jeans while still feeling really wavy.

There is no rapping by Edan on this. Which is however you feel. Some people think his 88 Big Daddy Kane rhymestyles are hard. Some people think it shows that he doesn’t listen to enough Freeway or Joey Jihad.

Just blends, backmasks, distorts,clavichords, kazoo’s, pedals, flanges. Echo Party keeps a fun, pleasent disorientation throughout the mix.
When he doubles up the vintage rap chants, its some thing like this: “i got a new rap. it’s all about space. i got a new rap. it’s all about space.space space space space.” then will add some other old rap shit like, ‘the economy, sucks, everyone is terrible. do you want to stay here or go to outerspace?’
Anyway. The top video is a good sampling of what the mix about. The bottom video is Edan handmaking the covers for the vinyl of Echo Party