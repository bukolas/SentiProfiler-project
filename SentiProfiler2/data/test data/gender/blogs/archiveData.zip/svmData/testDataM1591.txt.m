In the spirit of newborns arrivals life has been a little less planned and a little more hectic. One might say we have currently it all under control, but those changes day-to-day or night-to-night. However, on the average we all are currently above water. 

Alex has been doing well though; gaining weight, growing, eating, and sleeping. 

Nathan is a sponge. He is learning everything and anything. The explosion of words, sentences and thoughts has really begun in full force. His imagination really has kicked in and he trains, planes, and cars have places to go.

As a parent, the little things are really the highlights: a middle of the night kiss on the forehead from Nathan while snuggling him back to sleep, a toothless grin from Alex while singing to him, measuring tape races with Nathan on the kitchen floor, Alex sleeping on your chest.