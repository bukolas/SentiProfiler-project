I cannot believe the politicians we send to office. Are the politicians so afraid of not being reelected that they will not give an up or down vote?

I believe that everyone should have access to healthcare, and healthcare needs to be reformed at the most basic level. It frustrates me knowing the politicians do not have the courage to represent the people. It seems every topic is split between the party lines. 

No politician is working for the good of the people, they are all worried about playing politics. It's actually disgusting. Come November I plan on a clean sweep.... my personal belief is, two terms and you're out. Enough of career politicians, enough of politics as usual, enough of this nonsense.