She redefines the laws of thermodynamics:
a) Her food intake is like normal people but she spends infinite energy talking, chatting, debating, arguing, singing, dancing, organizing events, orkuting/facebooking (throwing chappals and kickin in rajinikanth's style),...studying too now a days;) ......wonder how she creates the additional energy!
b) When alone (with say X :P), she cares about everything....wants everything to be perfect, everything to be organized, and everything to be planned....and more so than often she gets them to be....

she lives life kingsize and would do anything to keep ppl around her as happy as her!