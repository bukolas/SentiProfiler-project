time 5! 5 months is a long time..
Even though I've made a return here for a number of reasons, none of them involving any kind of humor(I can hear tht sigh of relief), I'll keep this post short n Kaju-barfi-sweet..
I'll list some places where 5 months are very significant, and some places/situations where 5 months are hardly noticed..  - Waiting for semester to end, mid way into the very first lecture of the sem!
- A bored Govt official retiring in 5 months
- A farmer
- A 93 yr old woman waiting for her first Haj trip
- A Merchant navy guy setting sail..(timez nt too hard on the wife, she has her options)
- Small budget movie producer giving out his first cheque in the movie's name
- An engineer waiting for his company to call(ouch ouch..)
- A pregnant-again woman, who had a miscarriage last time round, in 5 months(sorry, never said its gonna be roses n butterflies)
- A virgin, set to marry in 5 months!
- Period between Friends seasons
- Man serving time in jail, with remorse
- Animals in captivity
- Waiting for that first joint as soon as Rehab ends

And now where its insignificant/time flies by

- Man serving time in jail, without remorse
- Guy West-bound under Student exchange program
- Person working in his dream firm in his dream profile
- Kid of a working couple, growing up(Dual-income-One-kid, they say??)
- Animals in the wild
- Me
- Investors when stock markets are soaring

Next up, issues..

Keep the Faith..