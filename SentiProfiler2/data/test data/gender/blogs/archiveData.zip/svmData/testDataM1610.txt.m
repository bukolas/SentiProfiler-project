I think that the book of Job was written for this very reason. Here we have a man who is deeply blessed of God. Things have gone so very well for him. And suddenly it all goes wrong. Not just slightly but deeply and in every way. Has he done wrong? Has he been spurned by God? No!

Job is never able to see the heavenly things. He is never shown the events of Satan's desire to tempt, and test Job. He is not shown God's pleasure in Job's upright living. He is never shown any of these things. But he is called to trust that God is in control no matter what. He is in control and powerfully good even if our feelings are wrong.

It is a beautiful test to be given the opportunity to have faith even in the depths of this dark night of the soul. We are called to yell out like Job from the ashes.

    "He said, “Naked I came from my mother’s womb, and naked I will return there. The Lord gives, and the Lord takes away. May the name of the Lord be blessed!” In all this Job did not sin, nor did he charge God with moral impropriety." (Job 1:21-22)

Why do we think that just because he doesn't feel close that he is not close? Why do we place so much emphasis on feeling? As if it was the deciding factor in our salvation, or God's relationship to us.