Yes, observers of the Kansas City Rights Voting Rights Massacre know about Mr. Hearnes and his work behind the scenes in our sister city, St. Louis and across the nation.

The article also talks a great deal about the REAL ID act. Missouri State Rep. Jim Guest (R-King City) is a national leader in opposing Real ID. Yet for some reason, the anti-REAL ID forces in Jefferson City didn't see the threat of voter ID laws.

Clearly the governor's office is aware of the issues. Matt Blunt was Secretary of State during the 2004 election. His chief of staff, Ed Martin was former chairman of the St. Louis City Board of Election Commissioners.

Yet where does the buck stop in the administering of Missouri's elections? The Governor? The Secretary of State? The County Clerks? The Board of Election Commissioners?

Yes and No. Welcome to the Missouri's segregated election system with anti-machine politics protection. Missouri's system is a result of Jim Crow laws and anti-Pendergast "reform" efforts.

Sigh. The work of reform is never done.