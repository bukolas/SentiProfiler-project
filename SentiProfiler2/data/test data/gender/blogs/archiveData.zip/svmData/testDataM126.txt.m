Because no one reads the newspaper, and SportsCenter's anchors are too perky for this early in the morning, Deadspin combs the best of the broadsheets and the blogosphere to bring you everything you need to know to start your day.

•Joshua Clottey blames his listless performance against Manny Pacquiao on a bad case of diarrhea. That would explain the lack of punches, but one would have expected him to dance more.

•The women's college basketball bracket has been announced, featuring UConn and a 63-team play-in tournament.

•Today, in players taking Spring Training too seriously: Cliff Lee got ejected after throwing at Chris Snyder. Both benches emptied, but no punches were thrown. Welcome to the Cactus League; those Grapefruit pussies wouldn't last a day.

•Who opens the new Meadowlands, the Jets or the Giants? Both! But really the Giants. The Jets get Monday Night Football, one day after the Giants have the first regular season game. It's said that a good compromise leaves everyone angry. Except the Giants.

•Michigan's only known wild Wolverine was found dead this weekend. There was no immediate word on what killed it, but experts suspect it was death by Evan Turner, or perhaps Rich Rodriguez.

•••••

Good work waking up today. We'll try to make it worth your while.