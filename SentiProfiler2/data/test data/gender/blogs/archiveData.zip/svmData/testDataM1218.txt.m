Perfectly timed for the week President Barack Obama is pushing the House to vote on ObamaCare, on tonight’s (Tuesday) episode of CBS’s The Good Wife, set at a Chicago law firm, the lawyers “battle a health insurance company that refuses to pay for urgent in-utero surgery.” The CBS.com plug for the March 16 episode: “In an emergency courtroom set up in a hospital, Alicia and Will battle Patti Nyholm and an insurance company that refuses to pay for life-saving in-utero surgery.”

The last time I critiqued The Good Wife (“CBS Drama Showcases Blank Book that Mocks Palin as Empty-Headed Dunce”), NewsReal blog’s David Forsmark contended the program “is both politically and (more importantly) dramatically complex” and deserves credit for showcasing liberal hypocrisy.

So, I’ll hold out hope this episode will deliver more than just simplistic vilification of an insurance company and might, given the plot involves “in-utero surgery,” also forward pro-life perspectives. Watch and see.

Read more: http://newsbusters.org/blogs/brent-baker/2010/03/16/prime-time-cbs-drama-target-health-insurance-company#ixzz0iPO585aO