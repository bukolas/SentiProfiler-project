I stood, suspended on gossamer words,
Trapped in sound and light they span out, simple
With gently placed phrasings they could not but call
And in these words, and motions, spinning truth
A gentler rhythm, a kinder rhyme breathes
Out, and in the audience, all air,
Stilled, and charged, and frozen in it’s glory,
As upon a platform below our feet
But above our minds, in incandescence
Framed in motions, truly daring in heart
and soulful intent, we are all acting
They seem to say, declaring it to us all,
Ah, but oh, I hear us all exhaling
What beauty in this act, there is, trailing.